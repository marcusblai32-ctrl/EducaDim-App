import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart' hide Text;
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../config/api_config.dart';
import '../i18n/text.dart';
import '../../features/courses/offline_media.dart';
import '../theme/colors.dart';

enum VideoKind { youtube, vimeo, drive, file }

class VideoSource {
  VideoSource(this.kind, this.src);
  final VideoKind kind;
  final String src;

  static final _yt = RegExp(r'^[A-Za-z0-9_-]{11}$');

  /// Même logique que le site (mobile_api/video.py) : YouTube, Vimeo, Google Drive, fichier direct.
  static VideoSource? parse(String? url) {
    final raw = (url ?? '').trim();
    final u = Uri.tryParse(raw);
    if (raw.isEmpty || u == null || !(u.scheme == 'http' || u.scheme == 'https') || u.host.isEmpty) return null;
    var host = u.host.toLowerCase();
    for (final p in ['www.', 'm.']) {
      if (host.startsWith(p)) host = host.substring(p.length);
    }
    final path = u.pathSegments.where((e) => e.isNotEmpty).toList();

    String? vid;
    if (host == 'youtu.be' && path.isNotEmpty) {
      vid = path[0];
    } else if (host == 'youtube.com' || host == 'youtube-nocookie.com' || host == 'music.youtube.com') {
      if (path.isNotEmpty && path[0] == 'watch') {
        vid = u.queryParameters['v'];
      } else if (path.length >= 2 && const ['embed', 'shorts', 'live', 'v'].contains(path[0])) {
        vid = path[1];
      }
    }
    if (vid != null && _yt.hasMatch(vid)) {
      return VideoSource(VideoKind.youtube,
          'https://www.youtube-nocookie.com/embed/$vid?rel=0&modestbranding=1&playsinline=1&iv_load_policy=3');
    }

    if (host == 'vimeo.com' || host == 'player.vimeo.com') {
      final i = path.indexWhere((p) => RegExp(r'^\d+$').hasMatch(p));
      if (i >= 0) {
        var h = u.queryParameters['h'];
        if (h == null && i + 1 < path.length && RegExp(r'^[0-9a-f]{6,}$').hasMatch(path[i + 1])) h = path[i + 1];
        var src = 'https://player.vimeo.com/video/${path[i]}?dnt=1&title=0&byline=0&portrait=0';
        if (h != null && RegExp(r'^[0-9a-f]+$').hasMatch(h)) src += '&h=$h';
        return VideoSource(VideoKind.vimeo, src);
      }
    }

    if (host == 'drive.google.com' && path.length >= 3 && path[0] == 'file' && path[1] == 'd') {
      return VideoSource(VideoKind.drive, 'https://drive.google.com/file/d/${path[2]}/preview');
    }
    return VideoSource(VideoKind.file, raw);
  }

  String get html {
    const css = 'html,body{margin:0;height:100%;background:#000;overflow:hidden}'
        'iframe,video{position:absolute;top:0;left:0;width:100%;height:100%;border:0;background:#000}'
        '#bar{position:absolute;top:8px;left:8px;display:flex;gap:8px;z-index:5}'
        '#bar button{display:flex;align-items:center;justify-content:center;min-width:34px;height:34px;background:rgba(15,23,42,.62);color:#fff;border:0;border-radius:17px;padding:0 8px;font:600 12px sans-serif}#bar button.on{background:#fff;color:#1b3f9c}'
        '#err{display:none;position:absolute;inset:0;color:#fff;font:14px sans-serif;text-align:center;padding:40% 16px 0;z-index:4}';
    final esc = const HtmlEscape(HtmlEscapeMode.attribute).convert(src);
    final body = kind == VideoKind.file
        // Lecteur HTML5 sans téléchargement, avec : -10 s / +10 s, vitesse, répétition, message d'erreur clair.
        ? '<video id="v" src="$esc" controls controlsList="nodownload noremoteplayback" disablePictureInPicture '
            'playsinline preload="metadata" oncontextmenu="return false"></video>'
            '<div id="err"></div>'
            '<div id="bar"><button aria-label="-10 s" onclick="s(-10)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 4v6h6"/><path d="M3.5 15a9 9 0 1 0 2.1-9.4L1 10"/><text x="12" y="15.2" font-size="7" font-weight="700" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg></button><button aria-label="+10 s" onclick="s(10)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 4v6h-6"/><path d="M20.5 15a9 9 0 1 1-2.1-9.4L23 10"/><text x="12" y="15.2" font-size="7" font-weight="700" text-anchor="middle" fill="currentColor" stroke="none">10</text></svg></button>'
            '<button id="sp" onclick="sp()">1x</button><button id="lp" aria-label="Répéter" onclick="lp()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg></button></div>'
            '<script>var v=document.getElementById("v"),R=[1,1.25,1.5,2,0.75],i=0;'
            'function s(n){v.currentTime=Math.max(0,v.currentTime+n)}'
            'function sp(){i=(i+1)%R.length;v.playbackRate=R[i];document.getElementById("sp").textContent=R[i]+"x"}'
            'function lp(){v.loop=!v.loop;document.getElementById("lp").classList.toggle("on",v.loop)}'
                        'v.addEventListener("error",function(){var e=document.getElementById("err");'
            'e.textContent="Vidéo illisible : utilisez le format MP4 (H.264 + AAC).";e.style.display="block"});</script>'
        : '<iframe src="$esc" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" '
            'allow="autoplay; encrypted-media; picture-in-picture; fullscreen"></iframe>';
    return '<!doctype html><html><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1"><style>$css</style></head>'
        '<body oncontextmenu="return false">$body</body></html>';
  }
}

/// Vidéo intégrée et contrôlée : pas de bouton de téléchargement, navigation verrouillée
/// (aucune sortie vers YouTube/Vimeo). Le lecteur ne se charge qu'au toucher (économie de données).
class ControlledVideo extends StatefulWidget {
  const ControlledVideo({super.key, required this.url, this.title});
  final String url;
  final String? title;
  @override
  State<ControlledVideo> createState() => _ControlledVideoState();
}

class _ControlledVideoState extends State<ControlledVideo> {
  bool _active = false;

  Future<void> _fullscreen(VideoSource s) async {
    setState(() => _active = false); // un seul lecteur à la fois
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => _FullscreenVideo(s)));
  }

  @override
  Widget build(BuildContext context) {
    final source = VideoSource.parse(widget.url);
    if (source == null) {
      return const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Text('Vidéo indisponible.'));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: _active
            ? Stack(children: [
                Positioned.fill(child: _VideoFrame(source)),
                Positioned(
                  top: 4,
                  right: 4,
                  child: IconButton.filledTonal(
                    tooltip: tr('Plein écran'),
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.fullscreen_rounded),
                    onPressed: () => _fullscreen(source),
                  ),
                ),
              ])
            : InkWell(
                // Windows : pas de WebView intégrée → la vidéo s'ouvre dans le navigateur du système.
                onTap: Theme.of(context).platform == TargetPlatform.windows
                    ? () => launchUrl(Uri.parse(widget.url), mode: LaunchMode.externalApplication)
                    : () => setState(() => _active = true),
                child: Container(
                  decoration: const BoxDecoration(gradient: EdColors.hero),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(
                      width: 62,
                      height: 62,
                      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                      child: const Icon(Icons.play_arrow_rounded, size: 40, color: EdColors.blue),
                    ),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        (widget.title ?? '').isNotEmpty ? widget.title! : tr('Lire la vidéo'),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ]),
                ),
              ),
      ),
    );
  }
}

class _VideoFrame extends StatefulWidget {
  const _VideoFrame(this.source);
  final VideoSource source;
  @override
  State<_VideoFrame> createState() => _VideoFrameState();
}

class _VideoFrameState extends State<_VideoFrame> {
  WebViewController? _c;
  String? _localPath;
  bool _pushing = false;
  bool _failed = false;

  static const _maxLocal = 150 * 1024 * 1024;

  @override
  void initState() {
    super.initState();
    _init();
  }

  String _mime(String url) {
    final u = url.toLowerCase().split('?').first;
    if (u.endsWith('.webm')) return 'video/webm';
    if (u.endsWith('.mov')) return 'video/quicktime';
    if (u.endsWith('.ogv')) return 'video/ogg';
    return 'video/mp4';
  }

  Future<void> _init() async {
    final s = widget.source;
    String html = s.html;
    if (s.kind == VideoKind.file) {
      // Copie téléchargée (cache privé de l'application) : lue hors ligne, sans réseau.
      final p = await OfflineMedia.localFile(s.src);
      if (p != null) {
        try {
          if (await File(p).length() <= _maxLocal) {
            _localPath = p;
            html = html.replaceFirst(RegExp(r'<video id="v" src="[^"]*"'), '<video id="v"');
          }
        } catch (_) {}
      }
    }
    late final WebViewController c;
    c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (r) {
          // Cadre principal : uniquement notre page. Les sous-cadres (le lecteur) restent libres.
          if (!r.isMainFrame) return NavigationDecision.navigate;
          final ok = r.url.startsWith(ApiConfig.siteUrl) || r.url.startsWith('about:') || r.url.startsWith('data:') || r.url.startsWith('blob:');
          return ok ? NavigationDecision.navigate : NavigationDecision.prevent;
        },
        onPageFinished: (_) {
          if (_localPath != null && !_pushing) _pushLocal(c);
        },
      ))
      ..loadHtmlString(html, baseUrl: ApiConfig.siteUrl);
    if (mounted) setState(() => _c = c);
  }

  /// Envoie le fichier local à la page par morceaux (le lecteur le lit depuis la mémoire : aucun fichier exposé).
  Future<void> _pushLocal(WebViewController c) async {
    _pushing = true;
    RandomAccessFile? raf;
    try {
      final f = File(_localPath!);
      final len = await f.length();
      await c.runJavaScript('window.__p=[];var ld=document.createElement("div");ld.id="ld";ld.textContent="Chargement…";'
          'ld.style.cssText="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;font:14px sans-serif;z-index:3";document.body.appendChild(ld);');
      raf = await f.open();
      const step = 384 * 1024; // multiple de 3 : chaque morceau base64 est indépendant
      for (var off = 0; off < len; off += step) {
        final bytes = await raf.read(step);
        if (!mounted) return;
        await c.runJavaScript('(function(){var b=atob("${base64Encode(bytes)}"),u=new Uint8Array(b.length);'
            'for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);window.__p.push(u)})()');
      }
      await c.runJavaScript('(function(){var bl=new Blob(window.__p,{type:"${_mime(widget.source.src)}"});window.__p=null;'
          'v.src=URL.createObjectURL(bl);var l=document.getElementById("ld");if(l)l.remove()})()');
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    } finally {
      await raf?.close();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const Center(child: Text('Vidéo illisible.', style: TextStyle(color: Colors.white)));
    }
    final c = _c;
    if (c == null) return const ColoredBox(color: Colors.black);
    return WebViewWidget(controller: c);
  }
}

class _FullscreenVideo extends StatelessWidget {
  const _FullscreenVideo(this.source);
  final VideoSource source;
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          leading: IconButton(
            tooltip: tr('Fermer'),
            icon: const Icon(Icons.close_rounded),
            onPressed: () => Navigator.of(context).pop(),
          ),
        ),
        body: Center(child: AspectRatio(aspectRatio: 16 / 9, child: _VideoFrame(source))),
      );
}
